<script setup lang="ts">
</script>

<template>
  <div class="summary">
    <h2>数据分析中心</h2>
    <p>这里是 summary 页面内容。</p>
  </div>
</template>

<style>
.summary {
  color: white;
}
</style>

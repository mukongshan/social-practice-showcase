<!-- src/App.vue -->
<script setup lang="ts">
import { RouterView, useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
</script>

<template>
  <div id="app">
    <!-- 顶部导航栏 -->
    <header class="app-header">
      <div class="header-content">
        <!-- 返回主页按钮 -->
        <button
            v-if="route.path !== '/'"
            @click="router.push('/')"
            class="back-button"
            title="返回主页"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
               xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19L5 12L12 5"
                  stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>主页</span>
        </button>

        <!-- 页面标题 -->
        <div class="title-container">
          <h1 class="page-title">
            <span class="title-text">
              {{ route.meta.title || '未命名页面' }}
            </span>
            <div class="title-underline"></div>
          </h1>
        </div>

        <!-- 右侧占位 -->
        <div class="header-spacer"></div>
      </div>
    </header>

    <!-- 主体内容 -->
    <main class="main-content">
      <RouterView />
    </main>
  </div>
</template>

<style>
/* 江南水乡主题 - 整体背景渐变 */
html, body, #app {
  height: 100%;
  width: 100vw;         /* 确保始终铺满窗口 */
  max-width: 100vw;     /* 防止子元素撑大 */
  margin: 0;
  padding: 0;
  overflow-x: hidden;   /* 禁止横向滚动 */
  box-sizing: border-box;
  /* 江南水乡背景 - 从水色到青绿的渐变，营造水乡氛围 */
  background: linear-gradient(135deg, #E8F4F8 0%, #B8E6E1 30%, #A8D5BA 70%, #D4E9D7 100%);
}

#app {
  min-height: 100vh;    /* 确保始终占满整个可见高度 */
  display: flex;
  flex-direction: column;
}

.main-content {
  flex: 1;
  min-height: 0;
  padding: 24px;
  animation: fadeIn 0.6s ease;
}

/* 顶部导航栏 - 江南水乡风格 */
.app-header {
  /* 半透明水色背景，营造水乡朦胧感 */
  background: rgba(72, 155, 140, 0.85);
  backdrop-filter: blur(20px);
  /* 江南水乡特色的边框 - 淡雅青色 */
  border-bottom: 2px solid rgba(74, 155, 140, 0.3);
  position: sticky;
  top: 0;
  z-index: 100;
  /* 水乡风格的阴影 - 柔和自然 */
  box-shadow: 0 4px 16px rgba(74, 155, 140, 0.2);
  animation: slideDown 0.5s ease;
}

.header-content {
  width: 100%;
  padding: 18px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 70px;
  box-sizing: border-box;
}

/* 返回按钮 - 江南水乡风格 */
.back-button {
  display: flex;
  align-items: center;
  gap: 8px;
  /* 江南水乡按钮背景 - 淡雅青绿渐变 */
  background: linear-gradient(135deg, rgba(74, 155, 140, 0.2), rgba(127, 176, 105, 0.2));
  /* 江南水乡边框 - 淡雅青色 */
  border: 1px solid rgba(74, 155, 140, 0.4);
  color: #2D5A4A;  /* 深青色文字，符合水乡特色 */
  padding: 8px 16px;
  border-radius: 12px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.25s ease;
  backdrop-filter: blur(12px);
}

.back-button:hover {
  /* 悬停时加深色彩，保持水乡风格 */
  background: linear-gradient(135deg, rgba(74, 155, 140, 0.35), rgba(127, 176, 105, 0.35));
  border-color: rgba(74, 155, 140, 0.6);
  color: #1a3d32;  /* 更深的青色 */
  transform: translateY(-2px);
  /* 水乡风格的阴影效果 */
  box-shadow: 0 6px 16px rgba(74, 155, 140, 0.3);
}

.back-button:active {
  transform: translateY(0);
}

/* 标题容器 */
.title-container {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}

/* 页面标题 - 江南水乡风格 */
.page-title {
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
  text-align: center;
  position: relative;
  letter-spacing: 0.02em;
}

.title-text {
  /* 江南水乡标题渐变 - 从深青色到青色，增加对比度 */
  background: linear-gradient(135deg, #1a3d32 0%, #2D5A4A 50%, #4A9B8C 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  /* 增加文字阴影，提高可读性 */
  text-shadow: 0 1px 2px rgba(255, 255, 255, 0.3);
  animation: glowText 3s ease-in-out infinite;
  
  /* 备用样式：如果渐变不支持，使用深色文字确保可读性 */
  color: #1a3d32;
}

/* 确保渐变文字在支持的环境中正确显示 */
@supports (-webkit-background-clip: text) or (background-clip: text) {
  .title-text {
    color: transparent;
  }
}

/* 标题下划线 - 江南水乡风格 */
.title-underline {
  position: absolute;
  bottom: -6px;
  left: 50%;
  transform: translateX(-50%);
  width: 60px;
  height: 3px;
  /* 江南水乡下划线 - 深青色渐变，增加对比度 */
  background: linear-gradient(135deg, #1a3d32 0%, #2D5A4A 100%);
  border-radius: 2px;
  /* 水乡风格的发光效果 */
  box-shadow: 0 0 12px rgba(74, 155, 140, 0.4);
  animation: pulse 2.5s infinite;
}

/* 占位 */
.header-spacer {
  flex: 1;
}

/* 动画效果 - 江南水乡风格 */
@keyframes slideDown {
  from { transform: translateY(-100%); opacity: 0; }
  to   { transform: translateY(0); opacity: 1; }
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}

@keyframes glowText {
  /* 江南水乡文字发光效果 - 增强对比度和可读性 */
  0%, 100% { 
    text-shadow: 
      0 1px 2px rgba(255, 255, 255, 0.4),
      0 0 6px rgba(26, 61, 50, 0.8); 
  }
  50% { 
    text-shadow: 
      0 1px 2px rgba(255, 255, 255, 0.5),
      0 0 8px rgba(45, 90, 74, 0.9),
      0 0 12px rgba(74, 155, 140, 0.6); 
  }
}

@keyframes pulse {
  0%, 100% { opacity: 0.8; transform: translateX(-50%) scaleX(1); }
  50% { opacity: 1; transform: translateX(-50%) scaleX(1.1); }
}

/* 响应式 */
@media (max-width: 768px) {
  .page-title { font-size: 1.6rem; }
  .title-underline { width: 40px; }
}

@media (max-width: 480px) {
  .page-title { font-size: 1.3rem; }
  .back-button span { display: none; }
  .back-button { padding: 8px; border-radius: 8px; }
}
</style>
